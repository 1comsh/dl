nala update && apt upgrade -y
