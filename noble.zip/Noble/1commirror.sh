echo "deb https://mirror.twds.com.tw/ubuntu/ noble main restricted universe multiverse" | sudo tee -a /etc/apt/sources.list
echo "deb https://repo.huaweicloud.com/ubuntu/ noble main restricted universe multiverse" | sudo tee -a /etc/apt/sources.list
