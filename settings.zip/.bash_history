sudo nala update && sudo apt upgrade -y
sudo nala clean
